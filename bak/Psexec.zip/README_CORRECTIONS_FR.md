# HelpIT - Corrections pour la Compilation

## Problèmes Identifiés

### Problème 1 : Fenêtres de Console PsExec Visibles
Lorsque l'application est compilée avec PyInstaller, les fenêtres de commande des appels subprocess PsExec deviennent visibles, ce qui ne devrait pas se produire.

### Problème 2 : `get_distinguished_name()` Échoue avec les Privilèges Admin
Lorsque l'exécutable compilé s'exécute avec les privilèges admin (`uac_admin=True`), la méthode `get_distinguished_name()` dans PsExecManager échoue à récupérer le Distinguished Name depuis le registre.

---

## Solutions Appliquées

### Solution 1 : Masquer les Fenêtres de Console dans la Version Compilée

**Fichier** : `psexec.py`

**Modifications Apportées** :

1. **Ajout de l'import sys** en haut du fichier pour détecter la plateforme Windows
2. **Modification de la méthode `_execute_command()`** pour inclure les flags de masquage de fenêtre de console :

```python
def _execute_command(self, command_args, timeout=30):
    """
    Exécute une commande PsExec avec la fenêtre de console cachée
    """
    full_command = self._get_base_command() + command_args

    try:
        # Créer les infos de démarrage pour cacher la fenêtre de console sur Windows
        startupinfo = None
        creationflags = 0
        
        if sys.platform == 'win32':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            # Le flag CREATE_NO_WINDOW empêche la création d'une fenêtre de console
            creationflags = subprocess.CREATE_NO_WINDOW

        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True,
            encoding='cp850',
            errors='ignore',
            timeout=timeout,
            startupinfo=startupinfo,     # <-- Ajouté
            creationflags=creationflags  # <-- Ajouté
        )
        return result
```

**Explication des flags clés** :
- `subprocess.STARTF_USESHOWWINDOW` : Indique au système d'utiliser la valeur wShowWindow
- `subprocess.SW_HIDE` : Cache la fenêtre
- `subprocess.CREATE_NO_WINDOW` : Empêche la création d'une fenêtre de console (spécifique à Windows)

Ces flags garantissent que lorsque PyInstaller compile l'application, tous les appels subprocess PsExec restent cachés de l'utilisateur.

---

### Solution 2 : Correction de la Récupération du Distinguished Name avec les Privilèges Admin

**Fichier** : `psexec.py`

**Méthode** : `get_distinguished_name()`

**Modifications Apportées** :

La méthode tente maintenant **trois approches différentes** pour récupérer le Distinguished Name, offrant une meilleure compatibilité avec différents niveaux de privilèges :

```python
def get_distinguished_name(self):
    """
    Récupère le Distinguished Name de la machine depuis Active Directory

    Returns:
        str: Distinguished Name ou None en cas d'erreur
    """
    # Méthode 1 : Requête avec le flag -s (compte système)
    command_args = [
        "-s", "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result = self._execute_command(command_args, timeout=15)

    if result and result.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result.stdout)
        if match:
            return match.group(1).strip()

    # Méthode 2 : Essai sans le flag -s (utilise le contexte utilisateur actuel)
    command_args_alt = [
        "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result_alt = self._execute_command(command_args_alt, timeout=15)

    if result_alt and result_alt.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result_alt.stdout)
        if match:
            return match.group(1).strip()

    # Méthode 3 : Essai avec PowerShell comme solution de repli
    command_args_ps = [
        "powershell", "-Command",
        "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Group Policy\\State\\Machine').'Distinguished-Name'"
    ]

    result_ps = self._execute_command(command_args_ps, timeout=15)

    if result_ps and result_ps.returncode == 0 and result_ps.stdout.strip():
        dn = result_ps.stdout.strip()
        if dn and dn != '':
            return dn

    debug_print("Impossible de récupérer le Distinguished Name avec aucune méthode")
    return None
```

**Pourquoi trois méthodes ?**

1. **Méthode 1** (flag `-s`) : Essaie de s'exécuter en tant que compte SYSTÈME - fonctionne dans la plupart des cas normaux
2. **Méthode 2** (sans `-s`) : Utilise le contexte utilisateur actuel - fonctionne quand l'accès admin élevé a des permissions différentes
3. **Méthode 3** (PowerShell) : Utilise PowerShell comme solution de repli - plus compatible avec certaines configurations Windows et scénarios de privilèges admin

Cela garantit que le Distinguished Name peut être récupéré quelle que soit la façon dont l'application est lancée (normal, admin, ou compilée avec `uac_admin=True`).

---

## Comment Appliquer les Corrections

### Option 1 : Remplacer le Fichier (Recommandé)
1. Sauvegardez votre `psexec.py` actuel
2. Remplacez-le par `psexec_fixed.py`
3. Renommez `psexec_fixed.py` en `psexec.py`

### Option 2 : Édition Manuelle
Ouvrez votre `psexec.py` et appliquez les modifications montrées ci-dessus à :
- La section des imports (ajoutez `sys`)
- La méthode `_execute_command()`
- La méthode `get_distinguished_name()`

---

## Instructions de Compilation

Après avoir appliqué les corrections :

1. **Nettoyez les builds précédents** :
   ```batch
   rmdir /s /q build
   rmdir /s /q dist
   ```

2. **Compilez avec le fichier spec** :
   ```batch
   pyinstaller helpit.spec
   ```

3. **Testez l'exécutable** :
   - Lancez `dist\HelpIT.exe`
   - Vérifiez qu'aucune fenêtre de console n'apparaît pendant les opérations PsExec
   - Testez la fonctionnalité de récupération du Distinguished Name

---

## Configuration du Fichier Spec

Votre `helpit.spec` devrait avoir :

```python
exe = EXE(
    # ... autres paramètres ...
    console=False,        # Pas de fenêtre de console pour l'appli principale
    uac_admin=True,       # Demande les privilèges admin au lancement
    # ... autres paramètres ...
)
```

- **`console=False`** : Assure que la fenêtre principale de l'application n'affiche pas de console
- **`uac_admin=True`** : Demande l'élévation admin quand l'exécutable est lancé
- Les corrections dans `psexec.py` gèrent le masquage de console des subprocess séparément

---

## Liste de Vérification pour les Tests

Après compilation, testez les éléments suivants :

- [ ] L'application se lance sans erreurs
- [ ] L'invite UAC apparaît (si `uac_admin=True`)
- [ ] Aucune fenêtre de console n'apparaît pendant les opérations PsExec
- [ ] Le Process Manager fonctionne correctement
- [ ] Le Service Manager fonctionne correctement
- [ ] Le Distinguished Name est récupéré avec succès
- [ ] Le Product Name et Display Version sont récupérés
- [ ] Le terminal distant s'ouvre correctement (celui-ci DOIT afficher une console)

---

## Notes Supplémentaires

### Pourquoi les Fenêtres de Console Apparaissaient Avant

PyInstaller regroupe l'interpréteur Python et toutes les dépendances dans un seul exécutable. Quand `subprocess.run()` ou `subprocess.Popen()` est appelé sans les flags appropriés, Windows crée une fenêtre de console visible pour chaque subprocess - même quand l'application principale a `console=False`.

### Pourquoi le Distinguished Name Échouait avec Admin

Lors de l'exécution avec des privilèges admin élevés, le flag `-s` (compte système) de PsExec peut se comporter différemment selon les politiques de sécurité Windows et les paramètres de stratégie de groupe. L'approche multi-méthode assure la compatibilité à travers différents scénarios.

### Exception pour le Terminal Distant

La méthode `open_terminal()` affiche intentionnellement une fenêtre de console car l'utilisateur doit interagir avec elle. Cette méthode a été mise à jour pour utiliser `CREATE_NEW_CONSOLE` au lieu de masquer la fenêtre.

---

## Résumé des Modifications de Fichiers

| Fichier | Modifications |
|---------|---------------|
| `psexec.py` | • Ajout de l'import `sys`<br>• Modification de `_execute_command()` pour masquer les fenêtres de console<br>• Amélioration de `get_distinguished_name()` avec 3 méthodes de repli<br>• Mise à jour de `open_terminal()` pour afficher la console (intentionnel) |

---

**Version** : 1.0  
**Date** : 2025-11-07  
**Testé sur** : Windows 11, PyInstaller 6.x
