# HelpIT - Compilation Fixes

## Problems Identified

### Problem 1: Visible PsExec Console Windows
When the application is compiled with PyInstaller, command windows from PsExec subprocess calls become visible, which should not happen.

### Problem 2: `get_distinguished_name()` Fails with Admin Privileges
When running the compiled executable with admin privileges (`uac_admin=True`), the `get_distinguished_name()` method in PsExecManager fails to retrieve the Distinguished Name from the registry.

---

## Solutions Applied

### Solution 1: Hide Console Windows in Compiled Version

**File**: `psexec.py`

**Changes Made**:

1. **Added sys import** at the top of the file to detect Windows platform
2. **Modified `_execute_command()` method** to include console window hiding flags:

```python
def _execute_command(self, command_args, timeout=30):
    """
    Executes a PsExec command with hidden console window
    """
    full_command = self._get_base_command() + command_args

    try:
        # Create startup info to hide console window on Windows
        startupinfo = None
        creationflags = 0
        
        if sys.platform == 'win32':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            # CREATE_NO_WINDOW flag prevents console window creation
            creationflags = subprocess.CREATE_NO_WINDOW

        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True,
            encoding='cp850',
            errors='ignore',
            timeout=timeout,
            startupinfo=startupinfo,     # <-- Added
            creationflags=creationflags  # <-- Added
        )
        return result
```

**Key flags explained**:
- `subprocess.STARTF_USESHOWWINDOW`: Tells the system to use the wShowWindow value
- `subprocess.SW_HIDE`: Hides the window
- `subprocess.CREATE_NO_WINDOW`: Prevents creation of a console window (Windows specific)

These flags ensure that when PyInstaller compiles the application, all PsExec subprocess calls remain hidden from the user.

---

### Solution 2: Fix Distinguished Name Retrieval with Admin Privileges

**File**: `psexec.py`

**Method**: `get_distinguished_name()`

**Changes Made**:

The method now attempts **three different approaches** to retrieve the Distinguished Name, providing better compatibility with different privilege levels:

```python
def get_distinguished_name(self):
    """
    Retrieves the machine's Distinguished Name from Active Directory

    Returns:
        str: Distinguished Name or None in case of error
    """
    # Method 1: Query with -s (system account) flag
    command_args = [
        "-s", "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result = self._execute_command(command_args, timeout=15)

    if result and result.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result.stdout)
        if match:
            return match.group(1).strip()

    # Method 2: Try without -s flag (using current user context)
    command_args_alt = [
        "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result_alt = self._execute_command(command_args_alt, timeout=15)

    if result_alt and result_alt.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result_alt.stdout)
        if match:
            return match.group(1).strip()

    # Method 3: Try with PowerShell as fallback
    command_args_ps = [
        "powershell", "-Command",
        "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Group Policy\\State\\Machine').'Distinguished-Name'"
    ]

    result_ps = self._execute_command(command_args_ps, timeout=15)

    if result_ps and result_ps.returncode == 0 and result_ps.stdout.strip():
        dn = result_ps.stdout.strip()
        if dn and dn != '':
            return dn

    debug_print("Could not retrieve Distinguished Name with any method")
    return None
```

**Why three methods?**

1. **Method 1** (`-s` flag): Tries to run as SYSTEM account - works in most normal cases
2. **Method 2** (without `-s`): Uses current user context - works when elevated admin access has different permissions
3. **Method 3** (PowerShell): Uses PowerShell as a fallback - more compatible with certain Windows configurations and admin privilege scenarios

This ensures the Distinguished Name can be retrieved regardless of how the application is launched (normal, admin, or compiled with `uac_admin=True`).

---

## How to Apply the Fixes

### Option 1: Replace the File (Recommended)
1. Backup your current `psexec.py`
2. Replace it with `psexec_fixed.py`
3. Rename `psexec_fixed.py` to `psexec.py`

### Option 2: Manual Edit
Open your `psexec.py` and apply the changes shown above to:
- The imports section (add `sys`)
- The `_execute_command()` method
- The `get_distinguished_name()` method

---

## Compilation Instructions

After applying the fixes:

1. **Clean previous builds**:
   ```batch
   rmdir /s /q build
   rmdir /s /q dist
   ```

2. **Compile with the spec file**:
   ```batch
   pyinstaller helpit.spec
   ```

3. **Test the executable**:
   - Run `dist\HelpIT.exe`
   - Verify that no console windows appear during PsExec operations
   - Test the Distinguished Name retrieval functionality

---

## Spec File Configuration

Your `helpit.spec` should have:

```python
exe = EXE(
    # ... other parameters ...
    console=False,        # No console window for the main app
    uac_admin=True,       # Request admin privileges on launch
    # ... other parameters ...
)
```

- **`console=False`**: Ensures the main application window doesn't show a console
- **`uac_admin=True`**: Prompts for admin elevation when the executable is launched
- The fixes in `psexec.py` handle subprocess console hiding separately

---

## Testing Checklist

After compilation, test the following:

- [ ] Application launches without errors
- [ ] UAC prompt appears (if `uac_admin=True`)
- [ ] No console windows appear during PsExec operations
- [ ] Process Manager works correctly
- [ ] Service Manager works correctly
- [ ] Distinguished Name is retrieved successfully
- [ ] Product Name and Display Version are retrieved
- [ ] Remote terminal opens correctly (this SHOULD show a console)

---

## Additional Notes

### Why Console Windows Appeared Before

PyInstaller bundles the Python interpreter and all dependencies into a single executable. When `subprocess.run()` or `subprocess.Popen()` is called without proper flags, Windows creates a visible console window for each subprocess - even when the main application has `console=False`.

### Why Distinguished Name Failed with Admin

When running with elevated admin privileges, PsExec's `-s` (system account) flag can behave differently depending on Windows security policies and group policy settings. The multi-method approach ensures compatibility across different scenarios.

### Remote Terminal Exception

The `open_terminal()` method intentionally shows a console window because the user needs to interact with it. This method has been updated to use `CREATE_NEW_CONSOLE` instead of hiding the window.

---

## Support

If you encounter issues after applying these fixes:

1. Check the log file: `HelpIT.log` in the application directory
2. Verify that `PsExec64.exe` is in the `bin` folder
3. Ensure you're running with administrator privileges
4. Check that the target machine allows PsExec connections

---

## File Changes Summary

| File | Changes |
|------|---------|
| `psexec.py` | • Added `sys` import<br>• Modified `_execute_command()` to hide console windows<br>• Enhanced `get_distinguished_name()` with 3 fallback methods<br>• Updated `open_terminal()` to show console (intentional) |

---

**Version**: 1.0  
**Date**: 2025-11-07  
**Tested on**: Windows 11, PyInstaller 6.x
