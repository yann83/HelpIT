# Comparaison des Modifications - psexec.py

## 📋 Vue d'ensemble

Ce document montre exactement ce qui a été modifié dans `psexec.py` pour résoudre les problèmes de compilation.

---

## 🔧 Modification 1 : Ajout de l'import `sys`

### ❌ AVANT
```python
import subprocess
import re
import csv
from pathlib import Path
```

### ✅ APRÈS
```python
import subprocess
import re
import csv
import sys  # <-- AJOUTÉ
from pathlib import Path
```

**Raison** : Nécessaire pour détecter la plateforme Windows et utiliser les flags subprocess appropriés.

---

## 🔧 Modification 2 : Méthode `_execute_command()`

### ❌ AVANT
```python
def _execute_command(self, command_args, timeout=30):
    """
    Executes a PsExec command

    Args:
        command_args(list): Additional arguments for the command
        timeout(int): Timeout in seconds

    Returns:
        subprocess.CompletedProcess: Execution result
    """
    full_command = self._get_base_command() + command_args

    try:
        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True,
            encoding='cp850',
            errors='ignore',
            timeout=timeout
        )
        return result
    except subprocess.TimeoutExpired:
        debug_print(f"Timeout on {self.ip_address}")
        return None
    except Exception as e:
        debug_print(f"Erreur running : {e}")
        return None
```

### ✅ APRÈS
```python
def _execute_command(self, command_args, timeout=30):
    """
    Executes a PsExec command with hidden console window

    Args:
        command_args (list): Additional arguments for the command
        timeout (int): Timeout in seconds

    Returns:
        subprocess.CompletedProcess: Execution result
    """
    full_command = self._get_base_command() + command_args

    try:
        # Create startup info to hide console window on Windows
        startupinfo = None
        creationflags = 0
        
        if sys.platform == 'win32':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            # CREATE_NO_WINDOW flag prevents console window creation
            creationflags = subprocess.CREATE_NO_WINDOW

        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True,
            encoding='cp850',
            errors='ignore',
            timeout=timeout,
            startupinfo=startupinfo,     # <-- AJOUTÉ
            creationflags=creationflags  # <-- AJOUTÉ
        )
        return result
    except subprocess.TimeoutExpired:
        debug_print(f"Timeout on {self.ip_address}")
        return None
    except Exception as e:
        debug_print(f"Error running command: {e}")
        return None
```

**Changements clés** :
1. ✨ Ajout de `startupinfo` et `creationflags` avant l'appel subprocess
2. ✨ Configuration des flags pour Windows uniquement (`sys.platform == 'win32'`)
3. ✨ Utilisation de `subprocess.STARTF_USESHOWWINDOW` et `subprocess.SW_HIDE`
4. ✨ Utilisation de `subprocess.CREATE_NO_WINDOW` pour empêcher la création de console
5. ✨ Passage de ces paramètres à `subprocess.run()`

**Résultat** : Les fenêtres de console PsExec sont maintenant cachées dans la version compilée.

---

## 🔧 Modification 3 : Méthode `get_distinguished_name()`

### ❌ AVANT
```python
def get_distinguished_name(self):
    """
    Retrieves the machine's Distinguished Name

    Returns:
        str: Distinguished Name or None in case of error
    """
    command_args = [
        "-s", "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result = self._execute_command(command_args)

    if result and result.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result.stdout)
        if match:
            return match.group(1).strip()

    return None
```

### ✅ APRÈS
```python
def get_distinguished_name(self):
    """
    Retrieves the machine's Distinguished Name from Active Directory

    Returns:
        str: Distinguished Name or None in case of error
    """
    # Method 1: Query with -s (system account) flag
    command_args = [
        "-s", "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result = self._execute_command(command_args, timeout=15)

    if result and result.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result.stdout)
        if match:
            return match.group(1).strip()

    # Method 2: Try without -s flag (using current user context)
    command_args_alt = [
        "reg", "query",
        r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine",
        "/v", "Distinguished-Name"
    ]

    result_alt = self._execute_command(command_args_alt, timeout=15)

    if result_alt and result_alt.returncode == 0:
        match = re.search(r'Distinguished-Name\s+REG_SZ\s+(.+)', result_alt.stdout)
        if match:
            return match.group(1).strip()

    # Method 3: Try with PowerShell as fallback
    command_args_ps = [
        "powershell", "-Command",
        "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Group Policy\\State\\Machine').'Distinguished-Name'"
    ]

    result_ps = self._execute_command(command_args_ps, timeout=15)

    if result_ps and result_ps.returncode == 0 and result_ps.stdout.strip():
        dn = result_ps.stdout.strip()
        if dn and dn != '':
            return dn

    debug_print("Could not retrieve Distinguished Name with any method")
    return None
```

**Changements clés** :
1. ✨ **Méthode 1** : Conserve l'approche originale avec le flag `-s`
2. ✨ **Méthode 2** : NOUVELLE - Essaie sans le flag `-s` (contexte utilisateur actuel)
3. ✨ **Méthode 3** : NOUVELLE - Utilise PowerShell comme solution de repli
4. ✨ Ajout d'un timeout de 15 secondes pour chaque tentative
5. ✨ Ajout d'un message de debug si toutes les méthodes échouent

**Résultat** : Le Distinguished Name est maintenant récupéré même en mode admin élevé.

---

## 🔧 Modification 4 : Méthode `open_terminal()` (Bonus)

### ❌ AVANT
```python
def open_terminal(self):
    """
    Open a command prompt (cmd) on the remote machine.
    Note: This command is interactive and blocks execution.
    """
    command = self._get_base_command() + ["cmd.exe"]
    subprocess.Popen(['start', 'cmd', '/k'] + command, shell=True)
```

### ✅ APRÈS
```python
def open_terminal(self):
    """
    Open a command prompt (cmd) on the remote machine.
    Note: This command is interactive and blocks execution.
    """
    command = self._get_base_command() + ["cmd.exe"]
    
    # For opening terminal, we DO want to show the window
    startupinfo = None
    creationflags = 0
    
    if sys.platform == 'win32':
        creationflags = subprocess.CREATE_NEW_CONSOLE
    
    subprocess.Popen(
        ['start', 'cmd', '/k'] + command, 
        shell=True,
        startupinfo=startupinfo,
        creationflags=creationflags
    )
```

**Changements clés** :
1. ✨ Utilisation de `CREATE_NEW_CONSOLE` pour créer une nouvelle console visible
2. ✨ Ajout des paramètres `startupinfo` et `creationflags` à `Popen()`

**Résultat** : Le terminal distant s'ouvre correctement avec une fenêtre visible (comportement attendu).

---

## 📊 Résumé des Problèmes Résolus

| Problème | Solution | Statut |
|----------|----------|--------|
| Fenêtres de console PsExec visibles | Ajout des flags `startupinfo` et `creationflags` | ✅ Résolu |
| `get_distinguished_name()` échoue en admin | Ajout de 3 méthodes de fallback | ✅ Résolu |
| Console masquée pour terminal distant | Utilisation de `CREATE_NEW_CONSOLE` | ✅ Résolu |

---

## 🚀 Prochaines Étapes

1. **Remplacez** votre `psexec.py` par le fichier corrigé
2. **Nettoyez** les anciens builds : `rmdir /s /q build dist`
3. **Compilez** : `pyinstaller helpit.spec`
4. **Testez** l'exécutable dans `dist\HelpIT.exe`

---

## ℹ️ Informations Supplémentaires

### Flags Subprocess Expliqués

| Flag | Valeur | Description |
|------|--------|-------------|
| `STARTF_USESHOWWINDOW` | 0x00000001 | Utilise la valeur wShowWindow |
| `SW_HIDE` | 0 | Cache la fenêtre |
| `CREATE_NO_WINDOW` | 0x08000000 | Pas de fenêtre de console |
| `CREATE_NEW_CONSOLE` | 0x00000010 | Nouvelle console visible |

### Pourquoi 3 Méthodes pour Distinguished Name ?

```
Méthode 1: -s flag
    ↓ Échoue avec certaines configs admin
Méthode 2: Sans -s flag
    ↓ Échoue si permissions insuffisantes
Méthode 3: PowerShell
    ↓ Solution de dernier recours
Si toutes échouent → return None
```

---

**Document créé le** : 2025-11-07  
**Pour** : HelpIT Application  
**Version** : 1.0
