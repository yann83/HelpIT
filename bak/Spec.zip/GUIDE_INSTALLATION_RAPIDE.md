# 🚀 Guide d'Installation Rapide - HelpIT Corrections

## ⚡ Installation en 5 Minutes

### Étape 1 : Sauvegarde
```batch
cd C:\CONFIDENTIEL\PROJETS\HelpIT
copy psexec.py psexec.py.backup
```

### Étape 2 : Remplacement
1. Téléchargez le fichier `psexec.py` corrigé
2. Remplacez votre `psexec.py` actuel avec le nouveau fichier

### Étape 3 : Nettoyage
```batch
rmdir /s /q build
rmdir /s /q dist
del /f /q HelpIT.exe
```

### Étape 4 : Compilation
```batch
pyinstaller helpit.spec
```

### Étape 5 : Test
```batch
cd dist
HelpIT.exe
```

---

## ✅ Checklist de Vérification

Testez les fonctionnalités suivantes :

- [ ] L'application démarre sans erreur
- [ ] L'invite UAC apparaît (demande admin)
- [ ] Validation d'une cible (IP/Hostname)
- [ ] Récupération du Distinguished Name (doit fonctionner maintenant !)
- [ ] Ouverture du Process Manager (pas de fenêtres console visibles !)
- [ ] Ouverture du Service Manager (pas de fenêtres console visibles !)
- [ ] Kill d'un processus (test avec notepad.exe par exemple)
- [ ] Ouverture du terminal distant (une console DOIT apparaître - c'est normal)

---

## 🔍 Vérification des Corrections

### Test 1 : Fenêtres Console Cachées ✅

**Comment tester** :
1. Lancez `HelpIT.exe`
2. Validez une cible (entrez un IP/hostname)
3. Cliquez sur "Process" ou "Service"
4. **Résultat attendu** : Aucune fenêtre CMD noire ne doit apparaître

**Si des fenêtres CMD apparaissent encore** :
- Vérifiez que vous avez bien remplacé `psexec.py`
- Vérifiez que `console=False` dans `helpit.spec`
- Recompilez avec `pyinstaller helpit.spec`

---

### Test 2 : Distinguished Name Fonctionne ✅

**Comment tester** :
1. Lancez `HelpIT.exe` en tant qu'administrateur
2. Validez une cible dans un domaine Active Directory
3. Regardez la zone "FQDN" en bas de l'application
4. **Résultat attendu** : Le Distinguished Name s'affiche (ex: `CN=COMPUTER,OU=Computers,DC=domain,DC=local`)

**Si le Distinguished Name est vide** :
- Vérifiez que la machine cible est dans un domaine AD
- Vérifiez dans le fichier `HelpIT.log` pour voir les messages d'erreur
- Essayez avec une autre machine du domaine

---

## 🐛 Résolution des Problèmes Courants

### Problème : "PsExec64.exe not found"
**Solution** :
```
Copiez PsExec64.exe dans le dossier :
C:\CONFIDENTIEL\PROJETS\HelpIT\bin\PsExec64.exe
```

### Problème : L'application ne démarre pas
**Solution** :
1. Vérifiez les logs : `HelpIT.log`
2. Vérifiez que `config.json` existe
3. Vérifiez les permissions (lancez en admin)

### Problème : "Module not found" lors de la compilation
**Solution** :
```batch
pip install --break-system-packages ping3 wakeonlan cryptography pywin32
```

### Problème : Les fenêtres console apparaissent toujours
**Solution** :
1. Vérifiez que vous utilisez le nouveau `psexec.py`
2. Vérifiez que `sys` est importé en haut du fichier
3. Recompilez complètement :
```batch
rmdir /s /q build dist __pycache__
pyinstaller helpit.spec
```

---

## 📝 Fichiers Modifiés

| Fichier Original | Nouveau Fichier | Action |
|-----------------|-----------------|---------|
| `psexec.py` | `psexec.py` (corrigé) | **Remplacer** |

**Un seul fichier à remplacer !**

---

## 🎯 Ce qui a été corrigé

### Correction #1 : Fenêtres Console
```python
# Code ajouté dans _execute_command()
if sys.platform == 'win32':
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = subprocess.SW_HIDE
    creationflags = subprocess.CREATE_NO_WINDOW
```

### Correction #2 : Distinguished Name
```python
# 3 méthodes de fallback ajoutées
# Méthode 1 : -s flag (SYSTEM)
# Méthode 2 : Sans -s (user context)
# Méthode 3 : PowerShell (fallback)
```

---

## 📞 Support

Si vous rencontrez des problèmes :

1. **Consultez** `HelpIT.log` dans le dossier de l'application
2. **Vérifiez** que tous les fichiers sont présents :
   - `bin/PsExec64.exe`
   - `config.json`
   - `config.sqlite` (créé automatiquement)
3. **Testez** en mode non-compilé avec `admin_main.cmd`
4. **Comparez** avec le fichier `psexec.py.backup` pour voir les différences

---

## 📚 Documentation Complète

Pour plus de détails, consultez :

- **README_CORRECTIONS_FR.md** : Explication détaillée des problèmes et solutions
- **COMPARISON_FR.md** : Comparaison avant/après avec le code
- **README_FIXES.md** : Version anglaise de la documentation

---

## ⏱️ Temps Estimé

| Étape | Temps |
|-------|-------|
| Sauvegarde et remplacement | 1 min |
| Nettoyage et compilation | 2-3 min |
| Tests de vérification | 1-2 min |
| **TOTAL** | **4-6 minutes** |

---

## ✨ Améliorations Futures Possibles

- [ ] Ajouter un indicateur de chargement pendant les requêtes PsExec
- [ ] Implémenter un cache pour le Distinguished Name
- [ ] Ajouter des logs plus détaillés pour le debugging
- [ ] Créer une interface pour afficher les logs en temps réel

---

**Dernière mise à jour** : 2025-11-07  
**Version** : 1.0  
**Testé avec** : Windows 11, Python 3.x, PyInstaller 6.x
