# -*- mode: python ; coding: utf-8 -*-

# PyInstaller spec file for HelpIT with admin elevation
# This file configures the build process for a one-file executable

block_cipher = None

a = Analysis(
    ['main.py'],  # Your main Python file
    pathex=[],
    binaries=[],
    datas=[
        ('pic/helpIT.ico', 'pic'),
    ],
    hiddenimports=[
        # GUI modules
        'tkinter',
        'tkinter.ttk',
        'tkinter.messagebox',
        'tkinter.filedialog',
        
        # Network and system modules
        'ping3',
        'socket',
        'ipaddress',
        
        # Wake-on-LAN
        'wakeonlan',
        
        # Cryptography
        'cryptography',
        'cryptography.fernet',
        'cryptography.hazmat',
        'cryptography.hazmat.primitives',
        'cryptography.hazmat.backends',
        
        # Windows specific
        'win32com',
        'win32com.client',
        'win32api',
        'win32con',
        'pywintypes',
        
        # Subprocess and system
        'subprocess',
        're',
        'csv',
        'pathlib',
        
        # Database
        'sqlite3',
        
        # Date and time
        'datetime',
        
        # JSON and config
        'json',
        'configparser',
        
        # Logging
        'logging',
        
        # File operations
        'os',
        'sys',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='HelpIT',  # Name of your executable
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,  # Compress with UPX (set to False if you don't have UPX)
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # Set to False for GUI application (no console window)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='pic/helpIT.ico',  # Optional: Add your icon file
    # THIS IS THE IMPORTANT LINE FOR ADMIN ELEVATION
    uac_admin=True,
)
